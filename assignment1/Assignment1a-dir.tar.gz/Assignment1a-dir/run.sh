#!/bin/bash


./compile searching_sequential
date
./searching_sequential
date
